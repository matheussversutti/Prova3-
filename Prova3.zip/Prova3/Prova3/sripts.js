const sTitulo = document.querySelector('#titulo')
const sAlbum = document.querySelector('#abum')
const sArtista= document.querySelector('#artista')
const sNota = document.querySelector('#nota')
const sGenero = document.querySelector('#genero')
const btnRegistrar = document.querySelector('#btn-submit')

let itens
let id

const getItensBD = () => JSON.parse(localStorage.getItem('dbfunc')) ?? []
const setItensBD = () => localStorage.setItem('dbfunc', JSON.stringify((itens)))

function insertItem(item, index){
    let tr = document.createElement('tr')

    tr.innerHTML = `
    <td>${item.titulo} </td>
    <td>${item.album} </td>
    <td>${item.artista} </td>
    <td>${item.nota} </td>
    <td>${item.genero} </td>
`
}


btnRegistrar.onclick = e =>{

    if(sTitulo.value == "" || sAlbum.value == "" || sArtista.value == "" || sNota.value == "" || sGenero.value == "")
    return 


e.preventDefault();

if (id  !== undefined ){
    itens[id].titulo = sTitulo.value
    itens[id].album = sAlbum.value
    itens[id].artista = sArtista.value
    itens[id].nota = sNota.value
    itens[id].genero= sGenero.value
}else{
    itens.push({'titulo': sTitulo.value, 'album': sAlbum.value, 'artista': sArtista.value, 'nota': sNota.value, 'genero': sGenero.value})

}
setItensBD()

    
}